#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @useDynLib redatamx, .registration = TRUE
#' @rawNamespace exportPattern("^[[:alpha:]]+")
## usethis namespace: end
NULL
